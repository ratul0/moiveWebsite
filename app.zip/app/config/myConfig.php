<?php

return array(
	'siteName'	=>	'Movie Website'
);


?>