<?php

class Movie extends \Eloquent {
	protected $table = 'movies';
	protected $guarded = [];
	public $timestamps = false;

}