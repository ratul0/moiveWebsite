<?php

class Genre extends \Eloquent {
	protected $table = 'types';
	protected $guarded = [];
	public $timestamps = false;

}