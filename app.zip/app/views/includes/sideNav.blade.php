

<div class="col-md-3">
	<div class="list-group">
        <a href="www.google.com"></a>
	</div>

	<div class="list-group">
		<a href="#" class="list-group-item">
		    Faculty
		</a>
		<a href="#" class="list-group-item">
		    Stuff
		</a>
		<a href="#" class="list-group-item">
		    Students
		</a>
	</div>
</div>