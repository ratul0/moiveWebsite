<hr/>
    <div class="footer text-right">
        &copy;copyright {{ date('Y') }}
    </div>